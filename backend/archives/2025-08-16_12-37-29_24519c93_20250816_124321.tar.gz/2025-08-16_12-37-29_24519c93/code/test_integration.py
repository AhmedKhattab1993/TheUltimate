"""
Integration test for MarketStructure strategy
Tests parameter passing from frontend to LEAN
"""

import json
import os
from datetime import datetime, date

# Example frontend request for manual symbols
manual_request = {
    "strategy_name": "MarketStructure",
    "start_date": "2024-01-01",
    "end_date": "2024-01-31", 
    "initial_cash": 100000,
    "symbols": ["AAPL", "MSFT", "GOOGL", "AMZN", "META"],
    "use_screener_results": False,
    "parameters": {
        "lower_timeframe": "5min",
        "higher_timeframe": "1hour",
        "pivot_bars": 20
    }
}

# Example frontend request for screener symbols
screener_request = {
    "strategy_name": "MarketStructure",
    "start_date": "2024-01-01",
    "end_date": "2024-01-31",
    "initial_cash": 100000,
    "symbols": [],  # Empty when using screener
    "use_screener_results": True,
    "parameters": {
        "lower_timeframe": "5min",
        "higher_timeframe": "1hour", 
        "pivot_bars": 15  # Different pivot bars
    }
}

# Example screener results file format
example_screener_results = {
    "timestamp": "2024-01-15T09:30:00",
    "filters": {
        "min_volume": 1000000,
        "min_price": 10,
        "max_price": 500,
        "gap_percent": 2.0
    },
    "symbols": [
        "NVDA", "AMD", "TSLA", "NFLX", "ROKU",
        "COIN", "SQ", "PYPL", "SHOP", "UBER"
    ],
    "count": 10
}

def test_parameter_conversion():
    """Test conversion of frontend parameters to LEAN format."""
    
    # Simulate what lean_runner.py does
    lean_config = {
        "algorithm-language": "Python",
        "parameters": {}
    }
    
    # Convert manual request
    request = manual_request
    lean_config["parameters"]["startDate"] = request["start_date"].replace("-", "")
    lean_config["parameters"]["endDate"] = request["end_date"].replace("-", "")
    lean_config["parameters"]["cash"] = str(request["initial_cash"])
    lean_config["parameters"]["symbols"] = ",".join(request["symbols"])
    lean_config["parameters"]["use_screener_results"] = str(request["use_screener_results"]).lower()
    
    # Map timeframe parameters
    resolution_map = {
        "1min": "Minute",
        "5min": "Minute5",
        "15min": "Minute15", 
        "30min": "Minute30",
        "1hour": "Hour",
        "daily": "Daily"
    }
    
    for key, value in request["parameters"].items():
        if key in ["lower_timeframe", "higher_timeframe"]:
            lean_config["parameters"][key] = resolution_map.get(value, value)
        else:
            lean_config["parameters"][key] = str(value)
    
    print("Manual Request - LEAN Config:")
    print(json.dumps(lean_config, indent=2))
    print("\n" + "="*50 + "\n")
    
    # Convert screener request
    lean_config_screener = {
        "algorithm-language": "Python",
        "parameters": {}
    }
    
    request = screener_request
    lean_config_screener["parameters"]["startDate"] = request["start_date"].replace("-", "")
    lean_config_screener["parameters"]["endDate"] = request["end_date"].replace("-", "")
    lean_config_screener["parameters"]["cash"] = str(request["initial_cash"])
    lean_config_screener["parameters"]["use_screener_results"] = str(request["use_screener_results"]).lower()
    lean_config_screener["parameters"]["screener_results_file"] = "/home/ahmed/TheUltimate/backend/screener_results/results_20240115_093000.json"
    
    for key, value in request["parameters"].items():
        if key in ["lower_timeframe", "higher_timeframe"]:
            lean_config_screener["parameters"][key] = resolution_map.get(value, value)
        else:
            lean_config_screener["parameters"][key] = str(value)
    
    print("Screener Request - LEAN Config:")
    print(json.dumps(lean_config_screener, indent=2))

def test_algorithm_initialization():
    """Test how the algorithm would initialize with different parameters."""
    
    print("\n" + "="*50 + "\n")
    print("Algorithm Initialization Tests:\n")
    
    # Test 1: Manual symbols
    print("1. Manual Symbols Configuration:")
    print("   - Symbols: AAPL, MSFT, GOOGL, AMZN, META")
    print("   - Equal allocation: 20% each")
    print("   - Lower TF: 5-minute bars")
    print("   - Higher TF: 1-hour bars")
    print("   - Pivot bars: 20 on each side")
    print("   - Intraday exit: 3:45 PM")
    
    # Test 2: Screener symbols
    print("\n2. Screener Symbols Configuration:")
    print("   - Symbols: Dynamic from screener (10 symbols)")
    print("   - Equal allocation: 10% each")
    print("   - Filters daily symbols based on date")
    print("   - Same timeframe settings")
    
    # Test 3: Mixed configuration
    print("\n3. Advanced Configuration:")
    print("   - Can combine manual + screener symbols")
    print("   - Supports different pivot periods")
    print("   - Handles gaps and pre-market data")

def test_trading_scenarios():
    """Test different trading scenarios."""
    
    print("\n" + "="*50 + "\n")
    print("Trading Scenarios:\n")
    
    scenarios = [
        {
            "name": "Bullish Break of Structure",
            "condition": "Price breaks above pivot high",
            "action": "Enter long position",
            "stop": "Below recent pivot low (2% buffer)",
            "exit": "Intraday exit at 3:45 PM"
        },
        {
            "name": "Bearish Break of Structure",
            "condition": "Price breaks below pivot low",
            "action": "Skip (long-only implementation)",
            "stop": "N/A",
            "exit": "N/A"
        },
        {
            "name": "Trailing Stop Update",
            "condition": "New pivot low formed while in position",
            "action": "Update stop loss to new pivot low",
            "stop": "Trails with market structure",
            "exit": "Stop hit or intraday exit"
        },
        {
            "name": "No Entry After 3:30 PM",
            "condition": "BOS signal after 3:30 PM",
            "action": "Ignore signal",
            "stop": "N/A",
            "exit": "N/A"
        }
    ]
    
    for i, scenario in enumerate(scenarios, 1):
        print(f"{i}. {scenario['name']}:")
        print(f"   Condition: {scenario['condition']}")
        print(f"   Action: {scenario['action']}")
        print(f"   Stop: {scenario['stop']}")
        print(f"   Exit: {scenario['exit']}")
        print()

if __name__ == "__main__":
    print("MarketStructure Strategy Integration Test")
    print("="*50 + "\n")
    
    test_parameter_conversion()
    test_algorithm_initialization()
    test_trading_scenarios()
    
    print("\nExample Screener Results File:")
    print(json.dumps(example_screener_results, indent=2))