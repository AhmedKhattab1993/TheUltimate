using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using QuantConnect;
using QuantConnect.Algorithm;
using QuantConnect.Data;
using QuantConnect.Data.Market;
using QuantConnect.Indicators;
using QuantConnect.Orders;
using Newtonsoft.Json;

namespace QuantConnect.Algorithm.CSharp
{
    /// <summary>
    /// MarketStructure Algorithm: Break of Structure (BOS) based trading
    /// Tracks pivot highs/lows for trend identification and trades breakouts
    /// </summary>
    public class MarketStructureAlgorithm : QCAlgorithm
    {
        // Symbol management
        private Dictionary<Symbol, SymbolData> _symbolData;
        private decimal _targetAllocation;
        private List<Symbol> _tradingSymbols;
        
        // Parameters
        private int _pivotBars;
        private Resolution _lowerTimeframe;
        private Resolution _higherTimeframe;
        private bool _useScreenerResults;
        private string _screenerResultsFile;
        
        // Time management for intraday trading
        private readonly TimeSpan _marketClose = new TimeSpan(16, 0, 0);
        private readonly TimeSpan _exitTime = new TimeSpan(15, 45, 0);
        private readonly TimeSpan _noEntryTime = new TimeSpan(15, 30, 0);
        
        public override void Initialize()
        {
            // Load parameters
            LoadParameters();
            
            // Initialize data structures
            _symbolData = new Dictionary<Symbol, SymbolData>();
            _tradingSymbols = new List<Symbol>();
            
            // Setup symbols
            SetupSymbols();
            
            // Calculate equal allocation
            _targetAllocation = _tradingSymbols.Count > 0 ? 1m / _tradingSymbols.Count : 0;
            
            // Schedule intraday exit - liquidate all positions before market close
            Schedule.On(DateRules.EveryDay(), 
                TimeRules.At(_exitTime.Hours, _exitTime.Minutes), 
                ExitAllPositions);
            
            // Set warm-up period for indicators
            SetWarmUp(TimeSpan.FromDays(30));
            
            Log($"MarketStructure initialized with {_tradingSymbols.Count} symbols, allocation: {_targetAllocation:P2} each");
        }
        
        private void LoadParameters()
        {
            // Dates and cash
            var startDate = GetParameter("startDate", "20240101");
            var endDate = GetParameter("endDate", "20241231");
            var cash = decimal.Parse(GetParameter("cash", "100000"));
            
            SetStartDate(
                int.Parse(startDate.Substring(0, 4)),
                int.Parse(startDate.Substring(4, 2)),
                int.Parse(startDate.Substring(6, 2))
            );
            
            SetEndDate(
                int.Parse(endDate.Substring(0, 4)),
                int.Parse(endDate.Substring(4, 2)),
                int.Parse(endDate.Substring(6, 2))
            );
            
            SetCash(cash);
            
            // Strategy parameters
            _pivotBars = int.Parse(GetParameter("pivot_bars", "20"));
            _useScreenerResults = bool.Parse(GetParameter("use_screener_results", "false"));
            _screenerResultsFile = GetParameter("screener_results_file", "");
            
            // Timeframe parameters with string mapping
            var lowerTf = GetParameter("lower_timeframe", "Minute5");
            var higherTf = GetParameter("higher_timeframe", "Hour");
            
            _lowerTimeframe = ParseResolution(lowerTf);
            _higherTimeframe = ParseResolution(higherTf);
        }
        
        private Resolution ParseResolution(string resolution)
        {
            return resolution.ToLower() switch
            {
                "minute" or "1min" => Resolution.Minute,
                "minute5" or "5min" => Resolution.Minute,  // Will use 5-min consolidator
                "minute15" or "15min" => Resolution.Minute, // Will use 15-min consolidator
                "minute30" or "30min" => Resolution.Minute, // Will use 30-min consolidator
                "hour" or "1hour" => Resolution.Hour,
                "daily" => Resolution.Daily,
                _ => Resolution.Minute
            };
        }
        
        private void SetupSymbols()
        {
            var symbols = new List<string>();
            
            if (_useScreenerResults && !string.IsNullOrEmpty(_screenerResultsFile))
            {
                // Load symbols from screener results
                symbols = LoadScreenerSymbols();
            }
            else
            {
                // Load symbols from parameter
                var symbolsParam = GetParameter("symbols", "SPY");
                symbols = symbolsParam.Split(',').Select(s => s.Trim()).ToList();
            }
            
            // Add symbols with minute resolution (base resolution)
            foreach (var symbol in symbols.Take(20)) // Limit to 20 symbols for performance
            {
                try
                {
                    var equity = AddEquity(symbol, Resolution.Minute);
                    var sym = equity.Symbol;
                    _tradingSymbols.Add(sym);
                    
                    // Create symbol data with indicators
                    var data = new SymbolData
                    {
                        Symbol = sym,
                        Security = equity
                    };
                    
                    // Setup multi-timeframe pivots
                    SetupIndicators(data);
                    
                    _symbolData[sym] = data;
                    
                    Log($"Added symbol: {symbol} with pivot detection");
                }
                catch (Exception e)
                {
                    Log($"Failed to add symbol {symbol}: {e.Message}");
                }
            }
        }
        
        private void SetupIndicators(SymbolData data)
        {
            // Create pivot indicators
            data.LowerTfPivots = new PivotPointsHighLow($"{data.Symbol}_Lower", _pivotBars, _pivotBars, 100);
            data.HigherTfPivots = new PivotPointsHighLow($"{data.Symbol}_Higher", _pivotBars, _pivotBars, 100);
            
            // Setup consolidators for different timeframes
            if (_lowerTimeframe == Resolution.Minute)
            {
                // 5-minute consolidator
                var fiveMinConsolidator = new TradeBarConsolidator(TimeSpan.FromMinutes(5));
                fiveMinConsolidator.DataConsolidated += (sender, bar) =>
                {
                    data.LowerTfPivots.Update(bar);
                    UpdatePivotLevels(data);
                };
                SubscriptionManager.AddConsolidator(data.Symbol, fiveMinConsolidator);
            }
            
            // Hour consolidator for higher timeframe
            var hourConsolidator = new TradeBarConsolidator(TimeSpan.FromHours(1));
            hourConsolidator.DataConsolidated += (sender, bar) =>
            {
                data.HigherTfPivots.Update(bar);
                UpdatePivotLevels(data);
            };
            SubscriptionManager.AddConsolidator(data.Symbol, hourConsolidator);
        }
        
        private void UpdatePivotLevels(SymbolData data)
        {
            // Update pivot high
            if (data.LowerTfPivots.IsReady && data.LowerTfPivots.Current.Value > 0)
            {
                var pivotValue = data.LowerTfPivots.Current.Value;
                
                // Check if this is a high or low pivot
                var currentBar = Securities[data.Symbol].Price;
                if (pivotValue > currentBar) // It's a pivot high
                {
                    data.LastPivotHigh = pivotValue;
                    data.PivotHighTime = Time;
                }
                else // It's a pivot low
                {
                    data.LastPivotLow = pivotValue;
                    data.PivotLowTime = Time;
                }
            }
        }
        
        private List<string> LoadScreenerSymbols()
        {
            var symbols = new List<string>();
            
            try
            {
                if (File.Exists(_screenerResultsFile))
                {
                    var json = File.ReadAllText(_screenerResultsFile);
                    dynamic results = JsonConvert.DeserializeObject(json);
                    
                    // Extract symbols array
                    if (results.symbols != null)
                    {
                        foreach (var symbol in results.symbols)
                        {
                            symbols.Add(symbol.ToString());
                        }
                    }
                    
                    Log($"Loaded {symbols.Count} symbols from screener results");
                }
            }
            catch (Exception e)
            {
                Log($"Error loading screener results: {e.Message}");
            }
            
            // Default to SPY if no symbols loaded
            if (symbols.Count == 0)
            {
                symbols.Add("SPY");
            }
            
            return symbols;
        }
        
        public override void OnData(Slice data)
        {
            if (IsWarmingUp) return;
            
            // Check each symbol for break of structure
            foreach (var kvp in _symbolData)
            {
                var symbol = kvp.Key;
                var symbolData = kvp.Value;
                
                if (!data.Bars.ContainsKey(symbol)) continue;
                
                var price = data.Bars[symbol].Close;
                
                // Check for break of structure
                CheckBreakOfStructure(symbolData, price);
                
                // Manage existing positions
                ManagePosition(symbolData, price);
            }
        }
        
        private void CheckBreakOfStructure(SymbolData data, decimal price)
        {
            // Don't enter new positions close to market close
            if (Time.TimeOfDay >= _noEntryTime) return;
            
            // Skip if we already have a position
            if (data.HasPosition) return;
            
            // Bullish BOS: Price breaks above pivot high
            if (data.LastPivotHigh > 0 && 
                price > data.LastPivotHigh && 
                data.CurrentTrend != TrendDirection.Bullish)
            {
                data.CurrentTrend = TrendDirection.Bullish;
                data.LastBosTime = Time;
                OnBullishBos(data, price);
            }
            // Bearish BOS: Price breaks below pivot low
            else if (data.LastPivotLow > 0 && 
                     price < data.LastPivotLow && 
                     data.CurrentTrend != TrendDirection.Bearish)
            {
                data.CurrentTrend = TrendDirection.Bearish;
                data.LastBosTime = Time;
                OnBearishBos(data, price);
            }
        }
        
        private void OnBullishBos(SymbolData data, decimal price)
        {
            if (!Portfolio[data.Symbol].Invested)
            {
                var quantity = CalculatePositionSize(data.Symbol, price);
                if (quantity > 0)
                {
                    var ticket = MarketOrder(data.Symbol, quantity);
                    
                    data.HasPosition = true;
                    data.IsLong = true;
                    data.EntryPrice = price;
                    data.EntryTime = Time;
                    data.StopLoss = data.LastPivotLow * 0.98m; // Stop below pivot low
                    
                    Log($"BOS Long Entry: {data.Symbol} at ${price:F2}, Stop: ${data.StopLoss:F2}");
                }
            }
        }
        
        private void OnBearishBos(SymbolData data, decimal price)
        {
            // For simplicity, this example only trades long
            // Short selling can be enabled by uncommenting below
            /*
            if (!Portfolio[data.Symbol].Invested)
            {
                var quantity = -CalculatePositionSize(data.Symbol, price);
                if (quantity < 0)
                {
                    var ticket = MarketOrder(data.Symbol, quantity);
                    
                    data.HasPosition = true;
                    data.IsLong = false;
                    data.EntryPrice = price;
                    data.EntryTime = Time;
                    data.StopLoss = data.LastPivotHigh * 1.02m; // Stop above pivot high
                    
                    Log($"BOS Short Entry: {data.Symbol} at ${price:F2}, Stop: ${data.StopLoss:F2}");
                }
            }
            */
        }
        
        private void ManagePosition(SymbolData data, decimal price)
        {
            if (!data.HasPosition || !Portfolio[data.Symbol].Invested) return;
            
            // Check stop loss
            if (data.IsLong && price <= data.StopLoss)
            {
                Liquidate(data.Symbol);
                data.ResetPosition();
                Log($"Stop Loss Hit: {data.Symbol} at ${price:F2}");
            }
            else if (!data.IsLong && price >= data.StopLoss)
            {
                Liquidate(data.Symbol);
                data.ResetPosition();
                Log($"Stop Loss Hit: {data.Symbol} at ${price:F2}");
            }
            
            // Update trailing stop based on new pivots
            if (data.IsLong && data.LastPivotLow > data.StopLoss)
            {
                data.StopLoss = data.LastPivotLow * 0.98m;
                Debug($"Trailing Stop Updated: {data.Symbol} to ${data.StopLoss:F2}");
            }
        }
        
        private decimal CalculatePositionSize(Symbol symbol, decimal price)
        {
            var targetValue = Portfolio.TotalPortfolioValue * _targetAllocation;
            var quantity = Math.Floor(targetValue / price);
            
            // Ensure we don't exceed available buying power
            var maxQuantity = Math.Floor(Portfolio.MarginRemaining / price) * 0.95m;
            
            return Math.Min(quantity, maxQuantity);
        }
        
        private void ExitAllPositions()
        {
            Log("Intraday Exit: Closing all positions");
            
            foreach (var kvp in _symbolData)
            {
                var symbol = kvp.Key;
                var data = kvp.Value;
                
                if (Portfolio[symbol].Invested)
                {
                    Liquidate(symbol);
                    data.ResetPosition();
                }
            }
        }
        
        public override void OnEndOfAlgorithm()
        {
            Log($"Algorithm completed. Final Portfolio Value: ${Portfolio.TotalPortfolioValue:F2}");
            
            // Log performance summary
            var winCount = 0;
            var lossCount = 0;
            var totalTrades = 0;
            
            foreach (var order in Transactions.GetOrders())
            {
                if (order.Status == OrderStatus.Filled)
                {
                    totalTrades++;
                }
            }
            
            Log($"Total Trades: {totalTrades}");
        }
    }
    
    /// <summary>
    /// Container for symbol-specific data and indicators
    /// </summary>
    public class SymbolData
    {
        public Symbol Symbol { get; set; }
        public Security Security { get; set; }
        
        // Pivot indicators
        public PivotPointsHighLow LowerTfPivots { get; set; }
        public PivotPointsHighLow HigherTfPivots { get; set; }
        
        // Pivot tracking
        public decimal LastPivotHigh { get; set; }
        public decimal LastPivotLow { get; set; }
        public DateTime PivotHighTime { get; set; }
        public DateTime PivotLowTime { get; set; }
        
        // Market structure
        public TrendDirection CurrentTrend { get; set; } = TrendDirection.Neutral;
        public DateTime LastBosTime { get; set; }
        
        // Position management
        public bool HasPosition { get; set; }
        public bool IsLong { get; set; }
        public decimal EntryPrice { get; set; }
        public DateTime EntryTime { get; set; }
        public decimal StopLoss { get; set; }
        
        public void ResetPosition()
        {
            HasPosition = false;
            IsLong = false;
            EntryPrice = 0;
            EntryTime = DateTime.MinValue;
            StopLoss = 0;
        }
    }
    
    public enum TrendDirection
    {
        Neutral,
        Bullish,
        Bearish
    }
}