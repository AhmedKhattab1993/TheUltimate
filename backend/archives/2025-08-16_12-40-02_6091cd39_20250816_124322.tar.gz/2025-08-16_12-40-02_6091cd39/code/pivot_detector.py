# Custom pivot detection logic for MarketStructure algorithm

class PivotDetector:
    """Simple pivot high/low detector that tracks price extremes."""
    
    def __init__(self, lookback_bars):
        self.lookback_bars = lookback_bars
        self.high_buffer = []
        self.low_buffer = []
        self.close_buffer = []
        self.last_pivot_high = 0
        self.last_pivot_low = 0
        
    def update(self, bar):
        """Update buffers with new bar data."""
        self.high_buffer.append(bar.high)
        self.low_buffer.append(bar.low)
        self.close_buffer.append(bar.close)
        
        # Keep only required bars
        max_size = 2 * self.lookback_bars + 1
        if len(self.high_buffer) > max_size:
            self.high_buffer.pop(0)
            self.low_buffer.pop(0)
            self.close_buffer.pop(0)
            
        # Check for pivots if we have enough bars
        if len(self.high_buffer) == max_size:
            self._check_for_pivots()
    
    def _check_for_pivots(self):
        """Check if the middle bar is a pivot high or low."""
        middle_idx = self.lookback_bars
        
        # Check for pivot high
        middle_high = self.high_buffer[middle_idx]
        is_pivot_high = True
        for i in range(len(self.high_buffer)):
            if i != middle_idx and self.high_buffer[i] >= middle_high:
                is_pivot_high = False
                break
        
        if is_pivot_high:
            self.last_pivot_high = middle_high
            
        # Check for pivot low
        middle_low = self.low_buffer[middle_idx]
        is_pivot_low = True
        for i in range(len(self.low_buffer)):
            if i != middle_idx and self.low_buffer[i] <= middle_low:
                is_pivot_low = False
                break
                
        if is_pivot_low:
            self.last_pivot_low = middle_low
    
    @property
    def is_ready(self):
        """Check if we have enough bars to detect pivots."""
        return len(self.high_buffer) >= 2 * self.lookback_bars + 1